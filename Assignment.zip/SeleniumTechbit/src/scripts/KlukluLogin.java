package scripts;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class KlukluLogin {
	public static WebDriver driver = null;
	static String path = System.getProperty("user.dir") + "/Drivers/chromedriver.exe";

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		// 1. Mouse event for language
		System.setProperty("webdriver.chrome.driver", path);
		driver = new ChromeDriver();
		// driver.manage().window().maximize();
		driver.get("https://kluklu.eu/#/home");
		Thread.sleep(5000);

		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//i[@class = 'fa fa-chevron-down']"))).build().perform();
		driver.findElement(By.xpath("//li[@onclick='onTippyItemClick(13)']")).click();
		Thread.sleep(5000);
		action.moveToElement(driver.findElement(By.xpath("//i[@class = 'fa fa-chevron-down']"))).build().perform();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//li[@onclick='onTippyItemClick(12)']")).click();
		System.out.println("Language change successful");
		Thread.sleep(5000);

		// .2 login
		driver.findElement(By.xpath("//span[@class = 'ng-binding']")).click();
		Set<String> handeler = driver.getWindowHandles();// for switching windows
		Iterator<String> it = handeler.iterator();
		String parentwindow = it.next();
		String childwindow = it.next();

		driver.switchTo().window(childwindow);

		WebDriverWait wait = new WebDriverWait(driver, 60); // for wait
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("exampleInputEmail1")));
		boolean status = element.isDisplayed();

		if (status) {

			driver.findElement(By.id("exampleInputEmail1")).sendKeys("Invalid UserName");
			driver.findElement(By.id("exampleInputPassword1")).sendKeys("Invalid Password");
			Thread.sleep(5000);
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			Thread.sleep(5000);
			System.out.println("Invalid login Successful");

			Thread.sleep(5000);
			driver.findElement(By.id("exampleInputEmail1")).clear();
			driver.findElement(By.id("exampleInputEmail1")).sendKeys("anjali009@yopmail.com");
			driver.findElement(By.id("exampleInputPassword1")).clear();
			driver.findElement(By.id("exampleInputPassword1")).sendKeys("Hosting@123");
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			System.out.println("Valid login Successful");
			Thread.sleep(10000);

			WebDriverWait wait1 = new WebDriverWait(driver, 60); // for wait
			WebElement element1 = wait1
					.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@class = 'material-icons']")));
			boolean status1 = element1.isDisplayed();

			if (status1) {
				action.moveToElement(driver.findElement(By.xpath("//a[@class = 'dropdown-toggle']"))).build().perform();
				driver.findElement(By.xpath("//a[@class = 'dropdown-toggle']")).click();
				Thread.sleep(5000);
				driver.findElement(By.xpath("//*[text() = 'Logout']")).click();
				System.out.println("Logout Successful");
				Thread.sleep(5000);
				driver.quit();
			}
		} else {
			System.out.println("Not done");
			driver.close();
		}

	}

}
